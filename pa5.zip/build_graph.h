#ifndef BUILD_GRAPH_H
#define BUILD_GRAPH_H

Graph* readGraph(char*);

#endif
