#ifndef WRITE_OUTPUT_H
#define WRITE_OUTPUT_H

int writeOutput1(char*, Graph*);
Path* writeOutput2(char*, Graph*);
int writeOutput3(char*, Path*);

#endif
