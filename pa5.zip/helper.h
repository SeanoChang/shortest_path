#ifndef HELPER_H
#define HELPER_H

int shouldHeapify(PQ, PQ, PQ);
int isAdjencent(GraphNode*, GraphNode*); 

#endif
